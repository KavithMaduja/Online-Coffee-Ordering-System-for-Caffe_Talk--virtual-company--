package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class caffe_Talk_MainActivity extends AppCompatActivity {

    private Button btnlogin;
    private Button btnregister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caffe__talk__main);

        //login button
        btnlogin = findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
               Intent myIntent= new Intent(getBaseContext(),loginActivity.class);
                startActivity(myIntent);
            }
        });
        //register button
        btnregister = findViewById(R.id.btnregister);
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myyintent = new Intent(getBaseContext(),customerRegisterActivity.class);
                startActivity(myyintent);
            }
        });

    }
}
