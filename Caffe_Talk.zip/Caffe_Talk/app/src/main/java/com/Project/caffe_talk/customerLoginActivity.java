package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class customerLoginActivity extends AppCompatActivity {

    EditText emails;
    EditText passwordd;
    Button btnlogin2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_login);

        emails = findViewById(R.id.mail);
        passwordd = findViewById(R.id.pw);
        btnlogin2 = findViewById(R.id.btnlogin2);

        btnlogin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                llogin();
            }
        });
    }

    public void llogin(){
        String email = emails.getText().toString();
        String password = passwordd.getText().toString();

        if (email.equals("") || password.equals(""))
        {
            Toast.makeText(this, "Email or Password Blank", Toast.LENGTH_LONG).show();
        }

        else if (null!=checkUser(email,password))
        {
            String db = checkUser(email,password);

            Intent myIntentt = new Intent(getBaseContext(), orderActivity.class);
            myIntentt.putExtra("caffe_talk",db);
            startActivity(myIntentt);
        }
        else {
            Toast.makeText(this, "Email or Password is Incorrect", Toast.LENGTH_LONG).show();
            emails.setText("");
            passwordd.setText("");
            emails.requestFocus();
        }
    }

    public String checkUser(String user,String passw)
    {
        SQLiteDatabase db = openOrCreateDatabase("caffe_talk",MODE_PRIVATE,null);
        Cursor cursor = db.rawQuery("select customer_id,email,password from caffe_talk_customers where email=? and password=?", new String[] {user,passw});
        if (cursor.getCount() > 0)
        {
            cursor.moveToFirst();
            String mail = cursor.getString(1);
            String passworrd = cursor.getString(2);
            SharedPreferences.Editor sp = getSharedPreferences("caffe_talk", MODE_PRIVATE).edit();
            sp.putString("mailname", mail);
            sp.apply();
            cursor.close();
            return user;
        } return null;

    }

}
