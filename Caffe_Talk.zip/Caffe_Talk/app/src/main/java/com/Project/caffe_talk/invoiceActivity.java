package com.Project.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class invoiceActivity extends AppCompatActivity {

    TextView amqt, laqt, moqt;
    String am, la, mo;

    TextView ampr, lapr, mopr, total;

    int ame, latt, moc, tot;
    DatabaseHelper mydb;
    Button btnOk,btnout;

    private TextView txtdate;
    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private String date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        mydb = new DatabaseHelper(this);

        amqt = findViewById(R.id.txt_ame_qty);
        laqt = findViewById(R.id.txt_latt_qty);
        moqt = findViewById(R.id.txt_mo_qty);

        ampr = findViewById(R.id.txt_ame_amt);
        lapr = findViewById(R.id.txt_latt_amt);
        mopr = findViewById(R.id.txt_mo_amt);
        total = findViewById(R.id.txt_total_price);

        am = getIntent().getExtras().getString("Value1");
        la = getIntent().getExtras().getString("Value2");
        mo = getIntent().getExtras().getString("Value3");


        amqt.setText(am);
        laqt.setText(la);
        moqt.setText(mo);

        txtdate = (TextView) findViewById(R.id.txtDate);

        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        date = dateFormat.format(calendar.getTime());
        txtdate.setText(date);

        int a = Integer.parseInt(amqt.getText().toString());
        ame = a * 370;
        ampr.setText(String.valueOf("Rs." + ame + "/="));

        int l = Integer.parseInt(laqt.getText().toString());
        latt = l * 440;
        lapr.setText(String.valueOf("Rs." + latt + "/="));

        int m = Integer.parseInt(moqt.getText().toString());
        moc = m * 480;
        mopr.setText(String.valueOf("Rs." + moc + "/="));

        tot = ame + latt + moc;
        total.setText(String.valueOf("Rs." + tot + "/="));


        btnOk = findViewById(R.id.btn_ok);
        AddData();

        btnout = findViewById(R.id.btn_logout);
        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getBaseContext(),caffe_Talk_MainActivity.class);
                startActivity(i);
            }
        });

    }

    public void AddData() {
        btnOk.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        boolean isInserted = mydb.saveData(ampr.getText().toString(),
                                lapr.getText().toString(),
                                mopr.getText().toString(),
                                total.getText().toString(),
                                txtdate.getText().toString());

                        if (isInserted = true)
                            Toast.makeText(invoiceActivity.this, "Invoice Data Saved", Toast.LENGTH_LONG).show();

                        else
                            Toast.makeText(invoiceActivity.this, "Invoice Data is not Saved", Toast.LENGTH_LONG).show();


                    }
                }
        );

    }
}

