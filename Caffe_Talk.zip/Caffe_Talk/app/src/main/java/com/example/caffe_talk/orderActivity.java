package com.example.caffe_talk;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class orderActivity extends AppCompatActivity {

    private Button btnOrder,btnOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        btnOrder = findViewById(R.id.btnOrder);
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent ConfirmorderIntent = new Intent(getBaseContext(),orderConfirmActivity.class);
                startActivity(ConfirmorderIntent);
            }
        });

        btnOut = findViewById(R.id.btnLogout);
        btnOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getBaseContext(),caffe_Talk_MainActivity.class);
                startActivity(i);
            }
        });



    }
}
