package com.example.caffe_talk;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "caffe_talk";

    public static final String TABLE1_NAME = "caffe_talk_customers";
    public static final String CUSTOMERS_COLUMN_1 = "customer_id";
    public static final String CUSTOMERS_COLUMN_2 = "customer_name";
    public static final String CUSTOMERS_COLUMN_3 = "contact_no";
    public static final String CUSTOMERS_COLUMN_4 = "email";
    public static final String CUSTOMERS_COLUMN_5 = "password";
    public static final String CUSTOMERS_COLUMN_6 = "photo";
    public static final String CUSTOMERS_COLUMN_7 = "register_date";


    public static final String TABLE2_NAME = "caffe_talk_orders";
    public static final String ORDERS_COLUMN_1 = "order_no";
    public static final String ORDERS_COLUMN_2 = "delivery_address";
    public static final String ORDERS_COLUMN_3 = "caffe_americano_qty";
    public static final String ORDERS_COLUMN_4 = "caffe_latte_qty";
    public static final String ORDERS_COLUMN_5 = "caffe_mocha_qty";
    public static final String ORDERS_COLUMN_6 = "order_date";

    public static final String TABLE3_NAME = "caffe_talk_incomes";
    public static final String INCOMES_COLUMN_1 = "income_no";
    public static final String INCOMES_COLUMN_2 = "caffe_americano_price";
    public static final String INCOMES_COLUMN_3 = "caffe_latte_price";
    public static final String INCOMES_COLUMN_4 = "caffe_mocha_price";
    public static final String INCOMES_COLUMN_5 = "total_amount";
    public static final String INCOMES_COLUMN_6 = "income_date";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE1_NAME + "(customer_id INTEGER PRIMARY KEY AUTOINCREMENT,customer_name TEXT, contact_no TEXT,email TEXT, password TEXT, photo BLOG, register_date DATE )");
        db.execSQL("create table " + TABLE2_NAME + "(order_no INTEGER PRIMARY KEY AUTOINCREMENT,delivery_address TEXT, caffe_americano_qty INTEGER,caffe_latte_qty INTEGER, caffe_mocha_qty INTEGER, order_date DATE )");
        db.execSQL("create table " + TABLE3_NAME + "(income_no INTEGER PRIMARY KEY AUTOINCREMENT,caffe_americano_price TEXT,caffe_latte_price TEXT, caffe_mocha_price TEXT,total_amount TEXT, income_date DATE )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE1_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE2_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE3_NAME);
        onCreate(db);
    }


    public boolean submitData(String customerName, String contactNo, String mail, String passWord, String image, String register_date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CUSTOMERS_COLUMN_2, customerName);
        contentValues.put(CUSTOMERS_COLUMN_3, contactNo);
        contentValues.put(CUSTOMERS_COLUMN_4, mail);
        contentValues.put(CUSTOMERS_COLUMN_5, passWord);
        contentValues.put(CUSTOMERS_COLUMN_6, image);
        contentValues.put(CUSTOMERS_COLUMN_7, register_date);

        long result = db.insert(TABLE1_NAME, null, contentValues);
        if (result == -1) {
            return false;
        } else
            return true;

    }

    public Cursor getAllCustomers() {
        SQLiteDatabase db = this.getWritableDatabase();
        db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE1_NAME, null);
        return res;
    }

    public boolean insertData(String deliveryAddress, String americanoQty, String latteQty, String mochaQty, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ORDERS_COLUMN_2, deliveryAddress);
        contentValues.put(ORDERS_COLUMN_3, americanoQty);
        contentValues.put(ORDERS_COLUMN_4, latteQty);
        contentValues.put(ORDERS_COLUMN_5, mochaQty);
        contentValues.put(ORDERS_COLUMN_6, date);

        long result = db.insert(TABLE2_NAME, null, contentValues);
        if (result == -1) {
            return false;
        } else
            return true;
    }

    public Cursor getAllOrders() {
        SQLiteDatabase db = this.getWritableDatabase();
        db = this.getReadableDatabase();
        Cursor re = db.rawQuery("select * from " + TABLE2_NAME, null);
        return re;
    }

    public boolean saveData(String amPR, String laPR, String moPR, String tot, String idate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(INCOMES_COLUMN_2, amPR);
        contentValues.put(INCOMES_COLUMN_3, laPR);
        contentValues.put(INCOMES_COLUMN_4, moPR);
        contentValues.put(INCOMES_COLUMN_5, tot);
        contentValues.put(INCOMES_COLUMN_6, idate);

        long result = db.insert(TABLE3_NAME, null, contentValues);
        if (result == -1) {
            return false;
        } else
            return true;

    }

    public Cursor getAllIncomes() {
        SQLiteDatabase db = this.getWritableDatabase();
       db = this.getReadableDatabase();
        Cursor r = db.rawQuery("select * from " + TABLE3_NAME, null);
        return r;
    }
}

