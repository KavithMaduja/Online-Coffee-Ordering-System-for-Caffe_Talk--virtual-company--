package com.example.caffe_talk;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class adminActivity extends AppCompatActivity {

    Button btnCus,btnOrd,btnInc,btnOut;

    DatabaseHelper mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        mydb = new DatabaseHelper(this);

        btnCus =  findViewById(R.id.btnCustomers);
        btnOrd = findViewById(R.id.btnOrders);
        btnInc =  findViewById(R.id.btnIncomes);
        btnOut =  findViewById(R.id.btnLogout);



        btnOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(getBaseContext(),caffe_Talk_MainActivity.class);
                startActivity(i);
            }
        });
        AllCustomers();
        AllOrders();
        AllIncomes();

    }

    public void AllCustomers() {
        btnCus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = mydb.getAllCustomers();
                if (res.getCount() == 0) {
                    //show message
                    showMessage("Error", "Nothing found");
                    return;
                }
                    StringBuffer buffer = new StringBuffer();
                    while (res.moveToNext()) {
                        buffer.append("customer_id : " + res.getString(0) + "\n");
                        buffer.append("customer_name : " + res.getString(1) + "\n");
                        buffer.append("contact_no : " + res.getString(2) + "\n");
                        buffer.append("email : " + res.getString(3) + "\n");
                        // buffer.append("password" + res.getString(4) + "\n");
                        // buffer.append("4to" + res.getString(5) + "\n");
                        buffer.append("register_date : " + res.getString(6) + "\n\n");
                    }
                    //show all data
                showMessage("Caffe_Talk_Customers",buffer.toString());
                }

        });
    }


    public void AllOrders() {
        btnOrd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor re = mydb.getAllOrders();
                if (re.getCount() == 0) {
                    //show message
                    showMessage("Error", "Nothing found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (re.moveToNext()) {
                    buffer.append("order_no : " + re.getString(0) + "\n");
                    buffer.append("delivery_address : " + re.getString(1) + "\n");
                    buffer.append("caffe_americano_qty : " + re.getString(2) + "\n");
                    buffer.append("caffe_latte_qty : " + re.getString(3) + "\n");
                    buffer.append("caffe_mocha_qty : " + re.getString(4) + "\n");
                    buffer.append("order_date : " + re.getString(5) + "\n\n");
                }
                //show all data
                showMessage("Caffe_Talk_Orders",buffer.toString());
            }
        });
    }

    public void AllIncomes() {
        btnInc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor r = mydb.getAllIncomes();
                if (r.getCount() == 0) {
                    //show message
                    showMessage("Error", "Nothing found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (r.moveToNext()) {
                    buffer.append("income_no : " + r.getString(0) + "\n");
                    buffer.append("caffe_americano_price : " + r.getString(1) + "\n");
                    buffer.append("caffe_latte_price : " + r.getString(2) + "\n");
                    buffer.append("caffe_mocha_price : " + r.getString(3) + "\n");
                    buffer.append("total_amount : " + r.getString(4) + "\n");
                    buffer.append("income_date : " + r.getString(5) + "\n\n");
                }
                //show all data
                showMessage("Caffe_Talk_Incomes",buffer.toString());
            }
        });
    }

    public void showMessage(String title2, String Message2) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title2);
        builder.setMessage(Message2);
        builder.show();
    }
}
